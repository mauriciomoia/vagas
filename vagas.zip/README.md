# Vagas

Sistema feito em Laravel e PHP onde faz-se cadastros de vagas e candidaturas a essas vagas.
